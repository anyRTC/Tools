#!/bin/sh
CLEAN_FLAG=0
if [ "$1" = "-u" ]; then
CLEAN_FLAG=1
fi

TARGET_PREFIX=/usr/local/artc

SYS_BIN_PATH=/usr/bin
CUR_PATH=$(cd "$(dirname "$0")"; pwd)

if [ "$CLEAN_FLAG" = "0" ]; then

#Install arfdfs service
  mkdir -p $TARGET_PREFIX
	tar -zxvf arfdfs.tar.gz -C $TARGET_PREFIX/ > /dev/null
  cp -rf config.toml $TARGET_PREFIX/arfdfs/conf
	cp $TARGET_PREFIX/arfdfs/arfdfs.service /usr/lib/systemd/system/
	cp $TARGET_PREFIX/arfdfs/arfdfs.sh /usr/bin/

	systemctl daemon-reload
	systemctl enable arfdfs
	systemctl start arfdfs

	printf "* install and start arfdfs service success.\r\n"
#end.
else
	systemctl stop arfdfs
	systemctl disable arfdfs
	rm -rf /usr/lib/systemd/system/arfdfs.service
	systemctl daemon-reload
	rm -rf $TARGET_PREFIX/arfdfs*
	rm -rf /usr/bin/arfdfs.sh

	printf "uninstall arfdfs service program...\r\n"
fi

